package com.noteworkshop.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;
import lombok.Data;

/**
 * 新建/编辑笔记请求
 */
@Data
public class NoteRequest {

    @NotBlank(message = "图书名称不能为空")
    private String bookName;

    @NotBlank(message = "标题不能为空")
    @Size(max = 200, message = "标题最长 200 字")
    private String title;

    private String content;

    /** 可见性：0 私有，1 公开 */
    private Integer visibility;
}
