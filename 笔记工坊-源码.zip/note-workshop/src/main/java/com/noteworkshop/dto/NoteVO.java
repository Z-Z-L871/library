package com.noteworkshop.dto;

import lombok.Data;

import java.time.LocalDateTime;
import java.util.List;

/**
 * 笔记视图对象：笔记 + 作者名 + 全部配图
 */
@Data
public class NoteVO {

    private Long id;
    private Long userId;
    private String authorName;
    private String bookName;
    private String title;
    private String content;
    private Integer visibility;
    private Integer likeCount;
    private List<String> images;
    private LocalDateTime createTime;
}
