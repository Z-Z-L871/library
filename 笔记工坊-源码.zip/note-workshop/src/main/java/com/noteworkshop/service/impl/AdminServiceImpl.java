package com.noteworkshop.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.noteworkshop.common.BusinessException;
import com.noteworkshop.entity.Note;
import com.noteworkshop.entity.NoteAudit;
import com.noteworkshop.entity.User;
import com.noteworkshop.mapper.NoteAuditMapper;
import com.noteworkshop.mapper.NoteMapper;
import com.noteworkshop.mapper.UserMapper;
import com.noteworkshop.security.UserContext;
import com.noteworkshop.service.AdminService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class AdminServiceImpl implements AdminService {

    private final UserMapper userMapper;
    private final NoteMapper noteMapper;
    private final NoteAuditMapper noteAuditMapper;

    /** 校验当前用户是否为管理员 */
    private void checkAdmin() {
        if (!UserContext.isAdmin()) {
            throw new BusinessException(403, "需要管理员权限");
        }
    }

    @Override
    public Page<User> listUsers(int page, int size) {
        checkAdmin();
        return userMapper.selectPage(new Page<>(page, size),
                new LambdaQueryWrapper<User>().orderByDesc(User::getId));
    }

    @Override
    public void setUserStatus(Long userId, Boolean status) {
        checkAdmin();
        User u = userMapper.selectById(userId);
        if (u == null) {
            throw new BusinessException("用户不存在");
        }
        if ("ADMIN".equals(u.getRole())) {
            throw new BusinessException("不能禁用管理员账号");
        }
        u.setStatus(status);
        userMapper.updateById(u);
    }

    @Override
    public Page<Note> listNotes(int page, int size) {
        checkAdmin();
        return noteMapper.selectPage(new Page<>(page, size),
                new LambdaQueryWrapper<Note>()
                        .eq(Note::getVisibility, 1)
                        .orderByDesc(Note::getCreateTime));
    }

    @Override
    public void auditNote(Long noteId, Boolean pass, String reason) {
        checkAdmin();
        Note note = noteMapper.selectById(noteId);
        if (note == null) {
            throw new BusinessException("笔记不存在");
        }
        int status = Boolean.TRUE.equals(pass) ? 1 : 2;
        note.setAuditStatus(status);
        noteMapper.updateById(note);

        // 写入审核记录
        NoteAudit audit = new NoteAudit();
        audit.setNoteId(noteId);
        audit.setAdminId(UserContext.getUserId());
        audit.setStatus(status);
        audit.setReason(reason == null ? "" : reason);
        noteAuditMapper.insert(audit);
    }
}
