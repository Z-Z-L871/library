package com.noteworkshop.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.noteworkshop.entity.Note;

public interface NoteMapper extends BaseMapper<Note> {
}
