package com.noteworkshop.controller;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.noteworkshop.common.Result;
import com.noteworkshop.entity.Note;
import com.noteworkshop.service.LikeService;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

/**
 * 点赞
 */
@RestController
@RequestMapping("/api/note")
@RequiredArgsConstructor
public class LikeController {

    private final LikeService likeService;

    @PostMapping("/{id}/like")
    public Result<Void> like(@PathVariable Long id) {
        likeService.like(id);
        return Result.success();
    }

    @DeleteMapping("/{id}/like")
    public Result<Void> unlike(@PathVariable Long id) {
        likeService.unlike(id);
        return Result.success();
    }

    @GetMapping("/liked")
    public Result<Page<Note>> liked(@RequestParam(defaultValue = "1") int page,
                                    @RequestParam(defaultValue = "10") int size) {
        return Result.success(likeService.listMyLikedNotes(page, size));
    }
}
