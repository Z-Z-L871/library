package com.noteworkshop.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.noteworkshop.entity.User;

public interface UserMapper extends BaseMapper<User> {
}
