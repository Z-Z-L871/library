package com.noteworkshop.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.noteworkshop.entity.NoteLike;

public interface NoteLikeMapper extends BaseMapper<NoteLike> {
}
