package com.noteworkshop.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.noteworkshop.common.BusinessException;
import com.noteworkshop.dto.LoginRequest;
import com.noteworkshop.dto.LoginResponse;
import com.noteworkshop.dto.RegisterRequest;
import com.noteworkshop.entity.User;
import com.noteworkshop.mapper.UserMapper;
import com.noteworkshop.security.JwtUtil;
import com.noteworkshop.security.UserContext;
import com.noteworkshop.service.UserService;
import com.noteworkshop.util.FileUploadUtil;
import lombok.RequiredArgsConstructor;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

@Service
@RequiredArgsConstructor
public class UserServiceImpl implements UserService {

    private final UserMapper userMapper;
    private final JwtUtil jwtUtil;
    private final FileUploadUtil fileUploadUtil;

    private final BCryptPasswordEncoder passwordEncoder = new BCryptPasswordEncoder();

    @Override
    public void register(RegisterRequest req) {
        Long count = userMapper.selectCount(
                new LambdaQueryWrapper<User>().eq(User::getUsername, req.getUsername()));
        if (count != null && count > 0) {
            throw new BusinessException("用户名已存在");
        }
        User u = new User();
        u.setUsername(req.getUsername());
        // 密码 BCrypt 加密，禁止明文
        u.setPassword(passwordEncoder.encode(req.getPassword()));
        u.setNickname(req.getNickname() == null || req.getNickname().isBlank()
                ? req.getUsername() : req.getNickname());
        u.setRole("USER");
        u.setStatus(true);
        userMapper.insert(u);
    }

    @Override
    public LoginResponse login(LoginRequest req) {
        User u = userMapper.selectOne(
                new LambdaQueryWrapper<User>().eq(User::getUsername, req.getUsername()));
        if (u == null || !passwordEncoder.matches(req.getPassword(), u.getPassword())) {
            throw new BusinessException("用户名或密码错误");
        }
        if (Boolean.FALSE.equals(u.getStatus())) {
            throw new BusinessException("账号已被禁用，请联系管理员");
        }
        String token = jwtUtil.generateToken(u.getId(), u.getRole());
        return new LoginResponse(token, u.getId(), u.getUsername(), u.getNickname(), u.getRole());
    }

    @Override
    public User getCurrentUser() {
        Long uid = UserContext.getUserId();
        if (uid == null) {
            throw new BusinessException(401, "未登录");
        }
        User u = userMapper.selectById(uid);
        if (u == null) {
            throw new BusinessException("用户不存在");
        }
        return u;
    }

    @Override
    public void updateProfile(String nickname) {
        User u = getCurrentUser();
        if (nickname != null && !nickname.isBlank()) {
            u.setNickname(nickname);
            userMapper.updateById(u);
        }
    }

    @Override
    public String uploadAvatar(MultipartFile file) {
        User u = getCurrentUser();
        String url = fileUploadUtil.saveImage(file);
        u.setAvatar(url);
        userMapper.updateById(u);
        return url;
    }
}
