/* ===== 笔记工坊 前端 API 封装 =====
 * 统一处理：请求地址、JWT token 自动携带、JSON 序列化、文件上传
 */

const API = {
    base: '',

    get token() { return localStorage.getItem('token'); },
    set token(v) { v ? localStorage.setItem('token', v) : localStorage.removeItem('token'); },

    // 通用 JSON 请求
    async request(method, url, data) {
        const headers = {};
        if (data !== undefined) headers['Content-Type'] = 'application/json';
        if (this.token) headers['Authorization'] = 'Bearer ' + this.token;

        const res = await fetch(this.base + url, {
            method,
            headers,
            body: data !== undefined ? JSON.stringify(data) : null
        });
        // 解析后端统一返回 {code, message, data}
        return res.json().catch(() => ({ code: res.status, message: '请求失败' }));
    },

    // 文件上传（multipart/form-data，FormData 由调用方构造）
    async upload(url, formData) {
        const headers = {};
        if (this.token) headers['Authorization'] = 'Bearer ' + this.token;
        const res = await fetch(this.base + url, { method: 'POST', headers, body: formData });
        return res.json().catch(() => ({ code: res.status, message: '请求失败' }));
    },

    get(url)  { return this.request('GET', url); },
    post(url, data) { return this.request('POST', url, data); },
    put(url, data)  { return this.request('PUT', url, data); },
    del(url) { return this.request('DELETE', url); }
};
