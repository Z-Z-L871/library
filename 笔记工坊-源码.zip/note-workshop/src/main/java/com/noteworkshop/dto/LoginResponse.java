package com.noteworkshop.dto;

import lombok.AllArgsConstructor;
import lombok.Data;

/**
 * 登录返回
 */
@Data
@AllArgsConstructor
public class LoginResponse {

    private String token;
    private Long id;
    private String username;
    private String nickname;
    private String role;
}
