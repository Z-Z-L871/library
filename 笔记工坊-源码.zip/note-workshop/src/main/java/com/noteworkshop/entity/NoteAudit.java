package com.noteworkshop.entity;

import com.baomidou.mybatisplus.annotation.FieldFill;
import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;

import java.time.LocalDateTime;

/**
 * 笔记审核记录
 */
@Data
@TableName("note_audit")
public class NoteAudit {

    @TableId(type = IdType.AUTO)
    private Long id;

    private Long noteId;

    private Long adminId;

    /** 审核结果：1 通过，2 驳回 */
    private Integer status;

    private String reason;

    @TableField(fill = FieldFill.INSERT)
    private LocalDateTime auditTime;
}
