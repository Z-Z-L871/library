package com.noteworkshop.dto;

import jakarta.validation.constraints.Size;
import lombok.Data;

/**
 * 修改资料请求
 */
@Data
public class UpdateProfileRequest {

    @Size(max = 30, message = "昵称最长 30 字")
    private String nickname;
}
