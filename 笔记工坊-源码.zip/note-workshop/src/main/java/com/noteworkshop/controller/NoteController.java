package com.noteworkshop.controller;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.noteworkshop.common.Result;
import com.noteworkshop.dto.NoteRequest;
import com.noteworkshop.dto.NoteVO;
import com.noteworkshop.entity.Note;
import com.noteworkshop.service.NoteService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RequestPart;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;

/**
 * 读书笔记
 */
@RestController
@RequestMapping("/api/note")
@RequiredArgsConstructor
public class NoteController {

    private final NoteService noteService;

    /**
     * 新建笔记，multipart/form-data 提交：
     *  data   = 笔记 JSON（bookName/title/content/visibility）
     *  images = 可选，可多张配图
     */
    @PostMapping
    public Result<Long> create(@Valid @RequestPart("data") NoteRequest req,
                               @RequestPart(value = "images", required = false) List<MultipartFile> images) {
        return Result.success(noteService.create(req, images));
    }

    @GetMapping("/public")
    public Result<Page<NoteVO>> publicNotes(@RequestParam(defaultValue = "1") int page,
                                            @RequestParam(defaultValue = "10") int size) {
        return Result.success(noteService.listPublicNotes(page, size));
    }

    @GetMapping("/my")
    public Result<Page<Note>> my(@RequestParam(defaultValue = "1") int page,
                                 @RequestParam(defaultValue = "10") int size) {
        return Result.success(noteService.listMyNotes(page, size));
    }

    @GetMapping("/{id}")
    public Result<NoteVO> detail(@PathVariable Long id) {
        return Result.success(noteService.getDetail(id));
    }

    @DeleteMapping("/{id}")
    public Result<Void> delete(@PathVariable Long id) {
        noteService.delete(id);
        return Result.success();
    }
}
