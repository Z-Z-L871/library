-- ============================================================
-- 笔记工坊 AI 读书笔记管理系统 - 数据库建表脚本 (MySQL 8.x)
-- 使用：mysql -u root -p < schema.sql
-- 涉及：用户 / 笔记 / 配图 / 点赞 / 关注 / 评论 / 审核 / AI 相关
-- ============================================================

CREATE DATABASE IF NOT EXISTS note_workshop
    DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE note_workshop;

-- ------------------------------------------------------------
-- 用户表（user 为 MySQL 保留字，统一反引号）
-- ------------------------------------------------------------
DROP TABLE IF EXISTS `user`;
CREATE TABLE `user` (
    id          BIGINT UNSIGNED NOT NULL AUTO_INCREMENT COMMENT '用户ID',
    username    VARCHAR(50)     NOT NULL                COMMENT '用户名(唯一)',
    password    VARCHAR(100)    NOT NULL                COMMENT 'BCrypt加密密码',
    nickname    VARCHAR(30)     DEFAULT ''              COMMENT '昵称',
    avatar      VARCHAR(255)    DEFAULT ''              COMMENT '头像URL',
    role        VARCHAR(20)     NOT NULL DEFAULT 'USER' COMMENT '角色: USER/ADMIN',
    status      TINYINT         NOT NULL DEFAULT 1      COMMENT '账号状态: 1启用 0禁用',
    deleted     TINYINT         NOT NULL DEFAULT 0      COMMENT '逻辑删除: 0正常 1删除',
    create_time DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    update_time DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
    PRIMARY KEY (id),
    UNIQUE KEY uk_username (username)
) ENGINE = InnoDB DEFAULT CHARSET = utf8mb4 COMMENT = '用户表';

-- ------------------------------------------------------------
-- 读书笔记表
-- ------------------------------------------------------------
DROP TABLE IF EXISTS note;
CREATE TABLE note (
    id          BIGINT UNSIGNED NOT NULL AUTO_INCREMENT COMMENT '笔记ID',
    user_id     BIGINT UNSIGNED NOT NULL                COMMENT '作者ID',
    book_name   VARCHAR(100)    NOT NULL                COMMENT '图书名称',
    title       VARCHAR(200)    NOT NULL                COMMENT '笔记标题',
    content     LONGTEXT                                COMMENT '笔记正文',
    visibility  TINYINT         NOT NULL DEFAULT 0      COMMENT '可见性: 0私有 1公开',
    audit_status TINYINT        NOT NULL DEFAULT 1      COMMENT '审核状态: 0待审核 1通过 2驳回(私有默认为1)',
    like_count  INT             NOT NULL DEFAULT 0      COMMENT '点赞数',
    ai_result_id BIGINT UNSIGNED DEFAULT NULL           COMMENT '已保存的AI辅助结果ID(一篇最多一种)',
    deleted     TINYINT         NOT NULL DEFAULT 0      COMMENT '逻辑删除: 0正常 1删除',
    create_time DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    update_time DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
    PRIMARY KEY (id),
    KEY idx_user (user_id),
    KEY idx_visibility (visibility),
    KEY idx_like (like_count)
) ENGINE = InnoDB DEFAULT CHARSET = utf8mb4 COMMENT = '读书笔记表';

-- ------------------------------------------------------------
-- 笔记配图表
-- ------------------------------------------------------------
DROP TABLE IF EXISTS note_image;
CREATE TABLE note_image (
    id          BIGINT UNSIGNED NOT NULL AUTO_INCREMENT COMMENT '图片ID',
    note_id     BIGINT UNSIGNED NOT NULL                COMMENT '所属笔记ID',
    url         VARCHAR(255)    NOT NULL                COMMENT '图片访问URL',
    create_time DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    PRIMARY KEY (id),
    KEY idx_note (note_id)
) ENGINE = InnoDB DEFAULT CHARSET = utf8mb4 COMMENT = '笔记配图表';

-- ------------------------------------------------------------
-- 点赞表
-- ------------------------------------------------------------
DROP TABLE IF EXISTS note_like;
CREATE TABLE note_like (
    id          BIGINT UNSIGNED NOT NULL AUTO_INCREMENT COMMENT '点赞ID',
    note_id     BIGINT UNSIGNED NOT NULL                COMMENT '笔记ID',
    user_id     BIGINT UNSIGNED NOT NULL                COMMENT '点赞用户ID',
    create_time DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    PRIMARY KEY (id),
    UNIQUE KEY uk_note_user (note_id, user_id)
) ENGINE = InnoDB DEFAULT CHARSET = utf8mb4 COMMENT = '点赞表';

-- ------------------------------------------------------------
-- 关注表（用户自关联）
-- ------------------------------------------------------------
DROP TABLE IF EXISTS follow;
CREATE TABLE follow (
    id          BIGINT UNSIGNED NOT NULL AUTO_INCREMENT COMMENT '关注ID',
    follower_id BIGINT UNSIGNED NOT NULL                COMMENT '关注者ID',
    followee_id BIGINT UNSIGNED NOT NULL                COMMENT '被关注者ID',
    create_time DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    PRIMARY KEY (id),
    UNIQUE KEY uk_follow (follower_id, followee_id),
    KEY idx_followee (followee_id)
) ENGINE = InnoDB DEFAULT CHARSET = utf8mb4 COMMENT = '关注表';

-- ------------------------------------------------------------
-- 评论表（支持二级/多级评论，parent_id 为空表示顶级）
-- ------------------------------------------------------------
DROP TABLE IF EXISTS `comment`;
CREATE TABLE `comment` (
    id          BIGINT UNSIGNED NOT NULL AUTO_INCREMENT COMMENT '评论ID',
    note_id     BIGINT UNSIGNED NOT NULL                COMMENT '笔记ID',
    user_id     BIGINT UNSIGNED NOT NULL                COMMENT '评论用户ID',
    parent_id   BIGINT UNSIGNED DEFAULT NULL            COMMENT '父评论ID,空为顶级评论',
    content     TEXT            NOT NULL                COMMENT '评论内容',
    deleted     TINYINT         NOT NULL DEFAULT 0      COMMENT '逻辑删除: 0正常 1删除',
    create_time DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    PRIMARY KEY (id),
    KEY idx_note (note_id),
    KEY idx_parent (parent_id)
) ENGINE = InnoDB DEFAULT CHARSET = utf8mb4 COMMENT = '评论表';

-- ------------------------------------------------------------
-- 笔记审核表（管理员审核公开笔记）
-- ------------------------------------------------------------
DROP TABLE IF EXISTS note_audit;
CREATE TABLE note_audit (
    id          BIGINT UNSIGNED NOT NULL AUTO_INCREMENT COMMENT '审核记录ID',
    note_id     BIGINT UNSIGNED NOT NULL                COMMENT '笔记ID',
    admin_id    BIGINT UNSIGNED NOT NULL                COMMENT '审核管理员ID',
    status      TINYINT         NOT NULL                COMMENT '审核结果: 1通过 2驳回',
    reason      VARCHAR(255)    DEFAULT ''              COMMENT '驳回原因',
    audit_time  DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '审核时间',
    PRIMARY KEY (id),
    KEY idx_note (note_id)
) ENGINE = InnoDB DEFAULT CHARSET = utf8mb4 COMMENT = '笔记审核表';

-- ------------------------------------------------------------
-- AI 辅助结果表（笔记总结/适宜人群/评分）
-- ------------------------------------------------------------
DROP TABLE IF EXISTS ai_result;
CREATE TABLE ai_result (
    id              BIGINT UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'AI结果ID',
    note_id         BIGINT UNSIGNED NOT NULL                COMMENT '笔记ID',
    summary         TEXT                                    COMMENT '笔记总结',
    target_audience TEXT                                    COMMENT '适宜人群',
    score           INT             DEFAULT NULL            COMMENT '评分(0-100)',
    status          TINYINT         NOT NULL DEFAULT 0      COMMENT '状态: 0待确认 1已保存 2已丢弃',
    create_time     DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    PRIMARY KEY (id),
    KEY idx_note (note_id)
) ENGINE = InnoDB DEFAULT CHARSET = utf8mb4 COMMENT = 'AI辅助结果表';

-- ------------------------------------------------------------
-- AI 智能客服会话表
-- ------------------------------------------------------------
DROP TABLE IF EXISTS ai_session;
CREATE TABLE ai_session (
    id          BIGINT UNSIGNED NOT NULL AUTO_INCREMENT COMMENT '会话ID',
    user_id     BIGINT UNSIGNED NOT NULL                COMMENT '归属用户ID',
    title       VARCHAR(100)    DEFAULT ''              COMMENT '会话标题',
    create_time DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    update_time DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
    PRIMARY KEY (id),
    KEY idx_user (user_id)
) ENGINE = InnoDB DEFAULT CHARSET = utf8mb4 COMMENT = 'AI客服会话表';

-- ------------------------------------------------------------
-- AI 客服消息表（用户与AI的多轮对话）
-- ------------------------------------------------------------
DROP TABLE IF EXISTS ai_message;
CREATE TABLE ai_message (
    id          BIGINT UNSIGNED NOT NULL AUTO_INCREMENT COMMENT '消息ID',
    session_id  BIGINT UNSIGNED NOT NULL                COMMENT '会话ID',
    role        VARCHAR(20)     NOT NULL                COMMENT '角色: user/assistant',
    content     TEXT            NOT NULL                COMMENT '消息内容',
    create_time DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    PRIMARY KEY (id),
    KEY idx_session (session_id)
) ENGINE = InnoDB DEFAULT CHARSET = utf8mb4 COMMENT = 'AI客服消息表';

-- ------------------------------------------------------------
-- AI 调用日志表（行为审计 / 管理员统计成功失败）
-- ------------------------------------------------------------
DROP TABLE IF EXISTS ai_log;
CREATE TABLE ai_log (
    id          BIGINT UNSIGNED NOT NULL AUTO_INCREMENT COMMENT '日志ID',
    user_id     BIGINT UNSIGNED DEFAULT NULL            COMMENT '调用用户ID',
    feature     VARCHAR(50)     NOT NULL                COMMENT '功能: 总结/评分/客服等',
    success     TINYINT         NOT NULL                COMMENT '是否成功: 1成功 0失败',
    message     VARCHAR(500)    DEFAULT ''              COMMENT '错误信息',
    create_time DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '调用时间',
    PRIMARY KEY (id),
    KEY idx_feature (feature),
    KEY idx_time (create_time)
) ENGINE = InnoDB DEFAULT CHARSET = utf8mb4 COMMENT = 'AI调用日志表';

-- ------------------------------------------------------------
-- 初始数据：管理员账号（密码需自行用 BCrypt 生成后替换）
-- ------------------------------------------------------------
-- INSERT INTO `user` (username, password, nickname, role, status)
-- VALUES ('admin', '<BCrypt密文>', '管理员', 'ADMIN', 1);
