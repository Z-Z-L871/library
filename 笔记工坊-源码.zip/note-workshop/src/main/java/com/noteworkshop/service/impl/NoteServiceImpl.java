package com.noteworkshop.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.noteworkshop.common.BusinessException;
import com.noteworkshop.dto.NoteRequest;
import com.noteworkshop.dto.NoteVO;
import com.noteworkshop.entity.Note;
import com.noteworkshop.entity.NoteImage;
import com.noteworkshop.entity.User;
import com.noteworkshop.mapper.NoteImageMapper;
import com.noteworkshop.mapper.NoteMapper;
import com.noteworkshop.mapper.UserMapper;
import com.noteworkshop.security.UserContext;
import com.noteworkshop.service.NoteService;
import com.noteworkshop.util.FileUploadUtil;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class NoteServiceImpl implements NoteService {

    private final NoteMapper noteMapper;
    private final NoteImageMapper noteImageMapper;
    private final UserMapper userMapper;
    private final FileUploadUtil fileUploadUtil;

    @Override
    @Transactional
    public Long create(NoteRequest req, List<MultipartFile> images) {
        Long uid = UserContext.getUserId();
        Note note = new Note();
        note.setUserId(uid);
        note.setBookName(req.getBookName());
        note.setTitle(req.getTitle());
        note.setContent(req.getContent());
        // visibility: 0 私有，1 公开
        int visibility = (req.getVisibility() == null) ? 0 : req.getVisibility();
        note.setVisibility(visibility);
        // 公开笔记进入审核队列（进阶功能：待管理员审核后才对外发布）
        note.setAuditStatus(visibility == 1 ? 0 : 1);
        note.setLikeCount(0);
        noteMapper.insert(note);

        if (images != null) {
            for (MultipartFile f : images) {
                if (f == null || f.isEmpty()) {
                    continue;
                }
                NoteImage img = new NoteImage();
                img.setNoteId(note.getId());
                img.setUrl(fileUploadUtil.saveImage(f));
                noteImageMapper.insert(img);
            }
        }
        return note.getId();
    }

    @Override
    public Page<NoteVO> listPublicNotes(int page, int size) {
        // 仅展示：公开 + 审核通过，按点赞数、创建时间倒序
        Page<Note> p = noteMapper.selectPage(new Page<>(page, size),
                new LambdaQueryWrapper<Note>()
                        .eq(Note::getVisibility, 1)
                        .eq(Note::getAuditStatus, 1)
                        .orderByDesc(Note::getLikeCount)
                        .orderByDesc(Note::getCreateTime));
        Page<NoteVO> vo = new Page<>(p.getCurrent(), p.getSize(), p.getTotal());
        vo.setRecords(p.getRecords().stream().map(this::toVO).collect(Collectors.toList()));
        return vo;
    }

    @Override
    public Page<Note> listMyNotes(int page, int size) {
        Long uid = UserContext.getUserId();
        Page<Note> p = new Page<>(page, size);
        return noteMapper.selectPage(p,
                new LambdaQueryWrapper<Note>()
                        .eq(Note::getUserId, uid)
                        .orderByDesc(Note::getCreateTime));
    }

    @Override
    public NoteVO getDetail(Long id) {
        Note note = noteMapper.selectById(id);
        if (note == null) {
            throw new BusinessException("笔记不存在");
        }
        // 权限：私有笔记仅作者本人或管理员可见
        if (note.getVisibility() == 0
                && !note.getUserId().equals(UserContext.getUserId())
                && !UserContext.isAdmin()) {
            throw new BusinessException(403, "无权查看该笔记");
        }
        return toVO(note);
    }

    /** Note -> NoteVO：补充作者名与全部配图 */
    private NoteVO toVO(Note n) {
        NoteVO vo = new NoteVO();
        vo.setId(n.getId());
        vo.setUserId(n.getUserId());
        vo.setBookName(n.getBookName());
        vo.setTitle(n.getTitle());
        vo.setContent(n.getContent());
        vo.setVisibility(n.getVisibility());
        vo.setLikeCount(n.getLikeCount());
        vo.setCreateTime(n.getCreateTime());

        User author = userMapper.selectById(n.getUserId());
        vo.setAuthorName(author != null ? author.getNickname() : "");

        List<String> images = noteImageMapper.selectList(
                        new LambdaQueryWrapper<NoteImage>().eq(NoteImage::getNoteId, n.getId()))
                .stream().map(NoteImage::getUrl).collect(Collectors.toList());
        vo.setImages(images);
        return vo;
    }

    @Override
    public void delete(Long id) {
        Note note = noteMapper.selectById(id);
        if (note == null) {
            throw new BusinessException("笔记不存在");
        }
        // 仅作者本人或管理员可删除
        if (!note.getUserId().equals(UserContext.getUserId()) && !UserContext.isAdmin()) {
            throw new BusinessException(403, "无权删除该笔记");
        }
        noteMapper.deleteById(id);
    }
}
