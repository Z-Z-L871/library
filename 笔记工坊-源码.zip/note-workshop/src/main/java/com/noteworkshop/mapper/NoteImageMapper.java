package com.noteworkshop.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.noteworkshop.entity.NoteImage;

public interface NoteImageMapper extends BaseMapper<NoteImage> {
}
