package com.noteworkshop.entity;

import com.baomidou.mybatisplus.annotation.FieldFill;
import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableLogic;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;

import java.time.LocalDateTime;

/**
 * 读书笔记
 */
@Data
@TableName("note")
public class Note {

    @TableId(type = IdType.AUTO)
    private Long id;

    private Long userId;

    /** 指定图书名称（可选：不建图书表，只存字符串） */
    private String bookName;

    private String title;

    private String content;

    /** 可见性：0 私有（仅自己可见），1 公开 */
    private Integer visibility;

    /** 审核状态：0 待审核，1 通过，2 驳回 */
    private Integer auditStatus;

    /** 点赞数 */
    private Integer likeCount;

    /** 已保存的 AI 辅助结果 id（一篇笔记最多保存一种） */
    private Long aiResultId;

    @TableLogic
    private Integer deleted;

    @TableField(fill = FieldFill.INSERT)
    private LocalDateTime createTime;

    @TableField(fill = FieldFill.INSERT_UPDATE)
    private LocalDateTime updateTime;
}
