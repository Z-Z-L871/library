package com.noteworkshop.controller;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.noteworkshop.common.Result;
import com.noteworkshop.entity.Note;
import com.noteworkshop.entity.User;
import com.noteworkshop.service.AdminService;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

/**
 * 管理员后台
 */
@RestController
@RequestMapping("/api/admin")
@RequiredArgsConstructor
public class AdminController {

    private final AdminService adminService;

    @GetMapping("/users")
    public Result<Page<User>> users(@RequestParam(defaultValue = "1") int page,
                                    @RequestParam(defaultValue = "10") int size) {
        return Result.success(adminService.listUsers(page, size));
    }

    @PutMapping("/user/{id}/status")
    public Result<Void> userStatus(@PathVariable Long id, @RequestParam Boolean status) {
        adminService.setUserStatus(id, status);
        return Result.success();
    }

    @GetMapping("/notes")
    public Result<Page<Note>> notes(@RequestParam(defaultValue = "1") int page,
                                    @RequestParam(defaultValue = "10") int size) {
        return Result.success(adminService.listNotes(page, size));
    }

    @PutMapping("/note/{id}/audit")
    public Result<Void> audit(@PathVariable Long id,
                              @RequestParam Boolean pass,
                              @RequestParam(required = false) String reason) {
        adminService.auditNote(id, pass, reason);
        return Result.success();
    }
}
