package com.noteworkshop.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.noteworkshop.entity.NoteAudit;

public interface NoteAuditMapper extends BaseMapper<NoteAudit> {
}
