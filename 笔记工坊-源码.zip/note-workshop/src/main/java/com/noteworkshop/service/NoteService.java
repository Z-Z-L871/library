package com.noteworkshop.service;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.noteworkshop.dto.NoteRequest;
import com.noteworkshop.dto.NoteVO;
import com.noteworkshop.entity.Note;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;

public interface NoteService {

    /** 新建笔记（可带多张配图） */
    Long create(NoteRequest req, List<MultipartFile> images);

    /** 公开笔记流（审核通过，按点赞数/时间排序，分页） */
    Page<NoteVO> listPublicNotes(int page, int size);

    /** 当前用户的所有笔记（分页） */
    Page<Note> listMyNotes(int page, int size);

    /** 笔记详情（含配图、作者名） */
    NoteVO getDetail(Long id);

    /** 删除笔记（仅作者或管理员） */
    void delete(Long id);
}
