/* ===== 笔记工坊 前端主逻辑 ===== */

/* ---------- 工具函数 ---------- */
function $(id) { return document.getElementById(id); }

function toast(msg, type) {
    const t = $('toast');
    t.textContent = msg;
    t.className = 'toast show ' + (type || '');
    setTimeout(() => { t.className = 'toast'; }, 2500);
}

// HTML 转义，防止 XSS
function esc(s) {
    return String(s ?? '').replace(/[&<>"']/g, c => ({
        '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;'
    }[c]));
}

// 后端 LocalDateTime -> 可读时间
function fmtTime(s) {
    if (!s) return '';
    return String(s).replace('T', ' ').slice(0, 16);
}

/* ---------- 视图切换 ---------- */
function showView(name) {
    document.querySelectorAll('.view').forEach(v => v.classList.remove('active'));
    const el = $('view-' + name);
    if (el) el.classList.add('active');

    document.querySelectorAll('.nav-link').forEach(a => {
        a.classList.toggle('active', a.dataset.view === name);
    });

    // 进入对应视图时刷新数据
    if (name === 'home') loadHome(1);
    if (name === 'mine') loadMine(1);
    if (name === 'admin') loadAdmin();
}

/* ---------- 导航栏：根据登录状态渲染 ---------- */
function renderNav() {
    const userArea = $('userArea');
    if (API.token) {
        const u = JSON.parse(localStorage.getItem('user') || '{}');
        userArea.innerHTML =
            '<span>👤 ' + esc(u.nickname || u.username || '') + '</span>' +
            '<button class="btn btn-sm btn-outline" id="btnLogout">退出</button>';
        $('btnLogout').onclick = logout;
        $('navAdmin').style.display = (u.role === 'ADMIN') ? '' : 'none';
    } else {
        userArea.innerHTML =
            '<button class="btn btn-sm btn-outline" data-view="login">登录</button>' +
            '<button class="btn btn-sm btn-outline" data-view="register">注册</button>';
        $('navAdmin').style.display = 'none';
    }
}

/* ---------- 认证 ---------- */
async function onLogin(e) {
    e.preventDefault();
    const fd = new FormData(e.target);
    const r = await API.post('/api/auth/login', {
        username: fd.get('username'),
        password: fd.get('password')
    });
    if (r.code !== 200) return toast(r.message || '登录失败', 'error');
    API.token = r.data.token;
    localStorage.setItem('user', JSON.stringify(r.data));
    toast('登录成功', 'success');
    renderNav();
    showView('home');
}

async function onRegister(e) {
    e.preventDefault();
    const fd = new FormData(e.target);
    const r = await API.post('/api/auth/register', {
        username: fd.get('username'),
        password: fd.get('password'),
        nickname: fd.get('nickname') || undefined
    });
    if (r.code !== 200) return toast(r.message || '注册失败', 'error');
    toast('注册成功，请登录', 'success');
    showView('login');
}

function logout() {
    API.token = null;
    localStorage.removeItem('user');
    toast('已退出');
    renderNav();
    showView('home');
}

/* ---------- 首页：公开笔记流 ---------- */
let homePage = 1;

async function loadHome(page) {
    homePage = page;
    const r = await API.get('/api/note/public?page=' + page + '&size=5');
    if (r.code !== 200) return toast(r.message || '加载失败', 'error');
    const data = r.data;
    renderNoteList($('homeList'), data.records || []);
    $('homePageInfo').textContent = '第 ' + page + ' 页 / 共 ' + Math.max(1, Math.ceil((data.total || 0) / 5)) + ' 页';
}

// 渲染笔记卡片列表
function renderNoteList(container, notes) {
    if (!notes.length) { container.innerHTML = '<p class="muted">暂无笔记</p>'; return; }
    container.innerHTML = notes.map(n => {
        const images = (n.images || []).map(u => '<img src="' + esc(u) + '">').join('');
        return '<div class="note-card">' +
            '<h3>' + esc(n.title) + '</h3>' +
            '<div class="note-meta">' +
                '<span>📖 ' + esc(n.bookName) + '</span>' +
                '<span>👤 ' + esc(n.authorName) + '</span>' +
                '<span>🕒 ' + esc(fmtTime(n.createTime)) + '</span>' +
                '<span>❤️ ' + (n.likeCount || 0) + '</span>' +
            '</div>' +
            '<div class="note-content">' + esc((n.content || '').slice(0, 120)) + '</div>' +
            '<div class="note-images">' + images + '</div>' +
            '<div class="note-actions">' +
                '<button class="btn btn-sm" onclick="loadDetail(' + n.id + ')">查看详情</button>' +
                '<button class="btn btn-sm like-btn" onclick="toggleLike(' + n.id + ', this)">👍 点赞</button>' +
            '</div>' +
        '</div>';
    }).join('');
}

// 点赞
async function toggleLike(id, btn) {
    const r = await API.post('/api/note/' + id + '/like');
    if (r.code !== 200) return toast(r.message || '操作失败', 'error');
    toast('已点赞', 'success');
    btn.classList.add('liked');
    btn.disabled = true;
}

/* ---------- 笔记详情 ---------- */
async function loadDetail(id) {
    const r = await API.get('/api/note/' + id);
    if (r.code !== 200) return toast(r.message || '加载失败', 'error');
    const n = r.data;
    const images = (n.images || []).map(u => '<img src="' + esc(u) + '">').join('');
    $('detailBox').innerHTML =
        '<h1>' + esc(n.title) + '</h1>' +
        '<div class="note-meta">' +
            '<span>📖 ' + esc(n.bookName) + '</span>' +
            '<span>👤 ' + esc(n.authorName) + '</span>' +
            '<span>🕒 ' + esc(fmtTime(n.createTime)) + '</span>' +
            '<span>❤️ ' + (n.likeCount || 0) + '</span>' +
        '</div>' +
        '<div class="note-images">' + images + '</div>' +
        '<div class="content">' + esc(n.content || '') + '</div>' +
        '<div class="note-actions"><button class="btn" onclick="showView(\'home\')">← 返回</button></div>';
    showView('detail');
}

// 首页分页按钮
$('homePrev').onclick = () => loadHome(Math.max(1, homePage - 1));
$('homeNext').onclick = () => loadHome(homePage + 1);

/* ---------- 我的笔记 ---------- */
let minePage = 1;

async function loadMine(page) {
    minePage = page;
    const r = await API.get('/api/note/my?page=' + page + '&size=5');
    if (r.code !== 200) return toast(r.message || '加载失败', 'error');
    const data = r.data;
    const records = data.records || [];
    if (!records.length) {
        $('mineList').innerHTML = '<p class="muted">还没有笔记，点右上角"写笔记"新建</p>';
    } else {
        const visMap = { 1: '<span class="badge badge-green">公开</span>', 0: '<span class="badge badge-blue">私有</span>' };
        const audMap = { 0: '待审核', 1: '通过', 2: '驳回' };
        $('mineList').innerHTML = records.map(n =>
            '<div class="note-card">' +
                '<h3>' + esc(n.title) + '</h3>' +
                '<div class="note-meta">' +
                    '<span>📖 ' + esc(n.bookName) + '</span>' +
                    '<span>' + (visMap[n.visibility] || '') + '</span>' +
                    '<span>审核:' + (audMap[n.auditStatus] || n.auditStatus) + '</span>' +
                    '<span>🕒 ' + esc(fmtTime(n.createTime)) + '</span>' +
                    '<span>❤️ ' + (n.likeCount || 0) + '</span>' +
                '</div>' +
                '<div class="note-content">' + esc((n.content || '').slice(0, 100)) + '</div>' +
                '<div class="note-actions">' +
                    '<button class="btn btn-sm" onclick="loadDetail(' + n.id + ')">查看</button>' +
                    '<button class="btn btn-sm btn-danger" onclick="deleteNote(' + n.id + ')">删除</button>' +
                '</div>' +
            '</div>'
        ).join('');
    }
    $('minePageInfo').textContent = '第 ' + page + ' 页 / 共 ' + Math.max(1, Math.ceil((data.total || 0) / 5)) + ' 页';
}

async function deleteNote(id) {
    if (!confirm('确定删除这篇笔记吗？')) return;
    const r = await API.del('/api/note/' + id);
    if (r.code !== 200) return toast(r.message || '删除失败', 'error');
    toast('已删除', 'success');
    loadMine(minePage);
}

// 我的笔记分页按钮
$('minePrev').onclick = () => loadMine(Math.max(1, minePage - 1));
$('mineNext').onclick = () => loadMine(minePage + 1);

/* ---------- 写笔记 ---------- */
async function onSaveNote(e) {
    e.preventDefault();
    const fd = new FormData(e.target);
    // 组装：data(笔记JSON) + images(多张图片)
    const formData = new FormData();
    const data = {
        bookName: fd.get('bookName'),
        title: fd.get('title'),
        content: fd.get('content'),
        visibility: parseInt(fd.get('visibility') || '0')
    };
    formData.append('data', new Blob([JSON.stringify(data)], { type: 'application/json' }));

    const files = e.target.images.files;
    for (let i = 0; i < files.length; i++) formData.append('images', files[i]);

    const r = await API.upload('/api/note', formData);
    if (r.code !== 200) return toast(r.message || '保存失败', 'error');
    toast('笔记已保存', 'success');
    e.target.reset();
    showView('mine');
}

/* ---------- 管理员后台 ---------- */
async function loadAdmin() {
    // 用户列表
    const ur = await API.get('/api/admin/users?page=1&size=20');
    if (ur.code === 403) { toast('需要管理员权限', 'error'); return; }
    if (ur.code !== 200) return toast(ur.message || '加载失败', 'error');
    const users = ur.data.records || [];
    $('adminUsers').innerHTML = users.length ?
        '<table><tr><th>ID</th><th>用户名</th><th>昵称</th><th>角色</th><th>状态</th><th>操作</th></tr>' +
        users.map(u =>
            '<tr><td>' + u.id + '</td><td>' + esc(u.username) + '</td><td>' + esc(u.nickname) + '</td>' +
            '<td>' + (u.role === 'ADMIN' ? '<span class="badge badge-blue">管理员</span>' : '用户') + '</td>' +
            '<td>' + (u.status ? '<span class="badge badge-green">启用</span>' : '<span class="badge badge-red">禁用</span>') + '</td>' +
            '<td>' + (u.role !== 'ADMIN'
                ? '<button class="btn btn-sm" onclick="setUserStatus(' + u.id + ',' + (u.status ? 'false' : 'true') + ')">' + (u.status ? '禁用' : '启用') + '</button>'
                : '<span class="muted">—</span>') + '</td></tr>'
        ).join('') + '</table>'
        : '<p class="muted">暂无用户</p>';

    // 公开笔记审核列表
    const nr = await API.get('/api/admin/notes?page=1&size=20');
    if (nr.code !== 200) return;
    const notes = nr.data.records || [];
    const audMap = { 0: '待审核', 1: '通过', 2: '驳回' };
    $('adminNotes').innerHTML = notes.length ?
        '<table><tr><th>ID</th><th>标题</th><th>作者ID</th><th>审核状态</th><th>操作</th></tr>' +
        notes.map(n =>
            '<tr><td>' + n.id + '</td><td>' + esc(n.title) + '</td><td>' + n.userId + '</td>' +
            '<td>' + (audMap[n.auditStatus] || n.auditStatus) + '</td>' +
            '<td>' + (n.auditStatus === 0
                ? '<button class="btn btn-sm" onclick="auditNote(' + n.id + ', true)">通过</button> ' +
                  '<button class="btn btn-sm btn-danger" onclick="auditNote(' + n.id + ', false)">驳回</button>'
                : '<span class="muted">已处理</span>') + '</td></tr>'
        ).join('') + '</table>'
        : '<p class="muted">暂无公开笔记</p>';
}

async function setUserStatus(id, status) {
    const r = await API.put('/api/admin/user/' + id + '/status?status=' + status);
    if (r.code !== 200) return toast(r.message || '操作失败', 'error');
    toast('操作成功', 'success');
    loadAdmin();
}

async function auditNote(id, pass) {
    let reason = '';
    if (!pass) reason = prompt('请输入驳回原因：') || '';
    const url = '/api/admin/note/' + id + '/audit?pass=' + pass +
        (reason ? '&reason=' + encodeURIComponent(reason) : '');
    const r = await API.put(url);
    if (r.code !== 200) return toast(r.message || '操作失败', 'error');
    toast(pass ? '审核通过' : '已驳回', 'success');
    loadAdmin();
}

/* ---------- 初始化 ---------- */
function init() {
    // 事件委托：动态生成的导航按钮(登录/注册/退出后新按钮)也能响应点击
    document.addEventListener('click', e => {
        const el = e.target.closest('[data-view]');
        if (el) showView(el.dataset.view);
    });
    $('loginForm').onsubmit = onLogin;
    $('registerForm').onsubmit = onRegister;
    $('noteForm').onsubmit = onSaveNote;

    renderNav();
    showView(API.token ? 'home' : 'login');
}

init();
