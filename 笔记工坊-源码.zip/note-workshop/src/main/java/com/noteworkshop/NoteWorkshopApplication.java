package com.noteworkshop;

import org.mybatis.spring.annotation.MapperScan;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * 笔记工坊 AI 读书笔记管理系统 - 启动类
 */
@SpringBootApplication
@MapperScan("com.noteworkshop.mapper")
public class NoteWorkshopApplication {

    public static void main(String[] args) {
        SpringApplication.run(NoteWorkshopApplication.class, args);
    }
}
