package com.noteworkshop.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.conditions.update.LambdaUpdateWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.noteworkshop.common.BusinessException;
import com.noteworkshop.entity.Note;
import com.noteworkshop.entity.NoteLike;
import com.noteworkshop.mapper.NoteLikeMapper;
import com.noteworkshop.mapper.NoteMapper;
import com.noteworkshop.security.UserContext;
import com.noteworkshop.service.LikeService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class LikeServiceImpl implements LikeService {

    private final NoteLikeMapper noteLikeMapper;
    private final NoteMapper noteMapper;

    @Override
    @Transactional
    public void like(Long noteId) {
        Long uid = UserContext.getUserId();
        Note note = noteMapper.selectById(noteId);
        if (note == null) {
            throw new BusinessException("笔记不存在");
        }
        if (note.getVisibility() != 1) {
            throw new BusinessException("只能点赞公开笔记");
        }
        Long count = noteLikeMapper.selectCount(
                new LambdaQueryWrapper<NoteLike>()
                        .eq(NoteLike::getNoteId, noteId)
                        .eq(NoteLike::getUserId, uid));
        if (count != null && count > 0) {
            throw new BusinessException("已经点赞过");
        }
        NoteLike like = new NoteLike();
        like.setNoteId(noteId);
        like.setUserId(uid);
        noteLikeMapper.insert(like);
        // 点赞数 +1
        noteMapper.update(null,
                new LambdaUpdateWrapper<Note>()
                        .eq(Note::getId, noteId)
                        .setSql("like_count = like_count + 1"));
    }

    @Override
    @Transactional
    public void unlike(Long noteId) {
        Long uid = UserContext.getUserId();
        int deleted = noteLikeMapper.delete(
                new LambdaQueryWrapper<NoteLike>()
                        .eq(NoteLike::getNoteId, noteId)
                        .eq(NoteLike::getUserId, uid));
        if (deleted > 0) {
            noteMapper.update(null,
                    new LambdaUpdateWrapper<Note>()
                            .eq(Note::getId, noteId)
                            .setSql("like_count = like_count - 1"));
        }
    }

    @Override
    public Page<Note> listMyLikedNotes(int page, int size) {
        Long uid = UserContext.getUserId();
        Page<NoteLike> likePage = noteLikeMapper.selectPage(new Page<>(page, size),
                new LambdaQueryWrapper<NoteLike>()
                        .eq(NoteLike::getUserId, uid)
                        .orderByDesc(NoteLike::getCreateTime));
        List<Long> noteIds = likePage.getRecords().stream()
                .map(NoteLike::getNoteId)
                .collect(Collectors.toList());
        Page<Note> result = new Page<>(likePage.getCurrent(), likePage.getSize(), likePage.getTotal());
        if (!noteIds.isEmpty()) {
            List<Note> notes = noteMapper.selectBatchIds(noteIds);
            result.setRecords(notes);
        }
        return result;
    }
}
