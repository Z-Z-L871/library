package com.noteworkshop.controller;

import com.noteworkshop.common.Result;
import com.noteworkshop.dto.UpdateProfileRequest;
import com.noteworkshop.entity.User;
import com.noteworkshop.service.UserService;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

/**
 * 用户信息
 */
@RestController
@RequestMapping("/api/user")
@RequiredArgsConstructor
public class UserController {

    private final UserService userService;

    @GetMapping("/me")
    public Result<User> me() {
        return Result.success(userService.getCurrentUser());
    }

    @PutMapping("/profile")
    public Result<Void> profile(@RequestBody UpdateProfileRequest req) {
        userService.updateProfile(req.getNickname());
        return Result.success();
    }

    @PostMapping("/avatar")
    public Result<String> avatar(@RequestParam("file") MultipartFile file) {
        return Result.success(userService.uploadAvatar(file));
    }
}
