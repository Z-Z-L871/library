package com.noteworkshop.service;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.noteworkshop.entity.Note;

public interface LikeService {

    /** 点赞公开笔记 */
    void like(Long noteId);

    /** 取消点赞 */
    void unlike(Long noteId);

    /** 当前用户点赞过的所有笔记（分页） */
    Page<Note> listMyLikedNotes(int page, int size);
}
