package com.noteworkshop.common;

/**
 * 自定义业务异常，配合全局异常处理器返回对应提示信息
 */
public class BusinessException extends RuntimeException {

    private final int code;

    public BusinessException(String message) {
        this(400, message);
    }

    public BusinessException(int code, String message) {
        super(message);
        this.code = code;
    }

    public int getCode() {
        return code;
    }
}
