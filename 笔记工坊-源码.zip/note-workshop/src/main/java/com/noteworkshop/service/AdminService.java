package com.noteworkshop.service;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.noteworkshop.entity.Note;
import com.noteworkshop.entity.User;

public interface AdminService {

    /** 用户列表（分页） */
    Page<User> listUsers(int page, int size);

    /** 禁用 / 启用用户 */
    void setUserStatus(Long userId, Boolean status);

    /** 全部公开笔记（含待审核，分页） */
    Page<Note> listNotes(int page, int size);

    /** 审核笔记：通过 / 驳回 */
    void auditNote(Long noteId, Boolean pass, String reason);
}
