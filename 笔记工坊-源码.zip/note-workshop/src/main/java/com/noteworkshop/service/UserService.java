package com.noteworkshop.service;

import com.noteworkshop.dto.LoginRequest;
import com.noteworkshop.dto.LoginResponse;
import com.noteworkshop.dto.RegisterRequest;
import com.noteworkshop.entity.User;
import org.springframework.web.multipart.MultipartFile;

public interface UserService {

    /** 注册 */
    void register(RegisterRequest req);

    /** 登录，返回 token */
    LoginResponse login(LoginRequest req);

    /** 获取当前登录用户 */
    User getCurrentUser();

    /** 修改昵称等资料 */
    void updateProfile(String nickname);

    /** 上传头像，返回访问 URL */
    String uploadAvatar(MultipartFile file);
}
